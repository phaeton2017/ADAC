import torch
import torch.nn as nn
from torchvision import models
import torch.nn.functional as F
from torch.nn import ReLU

from model import resnet_model
from model.backbone import mit_b4
from model.resnet_model import *
from model.segformer import SegFormer, SegFormerHead
from model.sync_batchnorm import SynchronizedBatchNorm2d
from model.MultiScaleFusion import MultiScaleFusion
from torchvision import transforms, utils
from torchvision.transforms import Resize
t_resize = Resize([384, 384])
class DiffNet(nn.Module):
    def __init__(self, in_ch, inc_ch):
        super(DiffNet, self).__init__()

        self.conv0 = nn.Conv2d(in_ch, inc_ch, 3, padding=1)

        self.conv1 = nn.Conv2d(inc_ch, 64, 3, padding=1)
        self.bn1 = SynchronizedBatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)

        self.pool1 = nn.MaxPool2d(2, 2, ceil_mode=True)

        self.conv2 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn2 = SynchronizedBatchNorm2d(64)
        self.relu2 = nn.ReLU(inplace=True)

        self.pool2 = nn.MaxPool2d(2,2,ceil_mode=True)

        self.conv3 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn3 = SynchronizedBatchNorm2d(64)
        self.relu3 = nn.ReLU(inplace=True)

        self.pool3 = nn.MaxPool2d(2, 2, ceil_mode=True)

        self.conv4 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn4 = SynchronizedBatchNorm2d(64)
        self.relu4 = nn.ReLU(inplace=True)

        self.pool4 = nn.MaxPool2d(2, 2, ceil_mode=True)


        self.conv5 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn5 = SynchronizedBatchNorm2d(64)
        self.relu5 = nn.ReLU(inplace=True)


        self.conv_d4 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d4 = SynchronizedBatchNorm2d(64)
        self.relu_d4 = nn.ReLU(inplace=True)

        self.conv_d3 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d3 = SynchronizedBatchNorm2d(64)
        self.relu_d3 = nn.ReLU(inplace=True)

        self.conv_d2 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d2 = SynchronizedBatchNorm2d(64)
        self.relu_d2 = nn.ReLU(inplace=True)

        self.conv_d1 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d1 = SynchronizedBatchNorm2d(64)
        self.relu_d1 = nn.ReLU(inplace=True)

        self.conv_d0 = nn.Conv2d(64, 1, 3, padding=1) #2
        self.conv_d10 = nn.Conv2d(1, 64, 3, padding=1) #ADD
        self.upscore2 = nn.Upsample(scale_factor=2, mode='bilinear',align_corners=False)


    def forward(self,x):
        # x = Resize([4, 1, 320, 320])
        hx = x
        # print('x:', hx.shape)
        hx = self.conv0(hx)
        # print('conv0:', hx.shape)
        hx1 = self.relu1(self.bn1(self.conv1(hx)))
        # print('relu:', hx1.shape)
        hx = self.pool1(hx1)
        # print('pool1:', hx.shape)

        hx2 = self.relu2(self.bn2(self.conv2(hx)))
        # print('conv2:', hx2.shape)
        hx = self.pool2(hx2)
        # print('pool2:', hx.shape)

        hx3 = self.relu3(self.bn3(self.conv3(hx)))
        # print('conv3', hx3.shape)
        hx = self.pool3(hx3)
        # print('pool3:', hx.shape)

        hx4 = self.relu4(self.bn4(self.conv4(hx)))
        # print('conv4:', hx4.shape)
        hx = self.pool4(hx4)
        # print('pool4:', hx.shape)

        hx5 = self.relu5(self.bn5(self.conv5(hx)))
        # print('conv5:', hx5.shape)
        hx = self.upscore2(hx5)
        # print('upscore2:', hx.shape)

        d4 = self.relu_d4(self.bn_d4(self.conv_d4(torch.cat((hx,hx4),1))))
        # print('conv_d4:', d4.shape)
        hx = self.upscore2(d4)
        # print('upscore:', hx.shape)

        d3 = self.relu_d3(self.bn_d3(self.conv_d3(torch.cat((hx,hx3),1))))
        # print('conv_d3:', d3.shape)
        hx = self.upscore2(d3)
        # print('upscore:', hx.shape)
        d2 = self.relu_d2(self.bn_d2(self.conv_d2(torch.cat((hx,hx2),1))))
        # print('conv_d2:', d2.shape)
        hx = self.upscore2(d2)
        # print('upscore:', hx.shape)

        d1 = self.relu_d1(self.bn_d1(self.conv_d1(torch.cat((hx,hx1),1))))
        # print('conv_d1:', d1.shape)
        #这个卷积报错了，试试用d2 d2可能放进 cov_d0(d2)

        residual = self.conv_d0(d1)
        # print('conv_d0:', residual.shape)
        x = x+residual
        # add = self.conv_d10(ori)
        # print(x.shape)
        # exit()
        return x

class BoundaryNets(nn.Module):
    def __init__(self,n_channels, n_classes):
        super(BoundaryNets,self).__init__()

        # resnet = models.resnet34(pretrained=True)

        ## -------------Encoder--------------

        # self.inconv = nn.Conv2d(n_channels, 64, 3, padding=1)
        # self.inbn = SynchronizedBatchNorm2d(64)
        # self.inrelu = nn.ReLU(inplace=True)
        #
        # self.encoder1 = resnet.layer1 #384
        # self.encoder2 = resnet.layer2 #192
        # self.encoder3 = resnet.layer3 #96
        # self.encoder4 = resnet.layer4 #48

        self.pool4 = nn.MaxPool2d(2,2,ceil_mode=True)

        # ------------multi scale fusion---------------
        # self.resb5_1 = BasicBlock(512, 512)
        # self.resb5_2 = BasicBlock(512, 512)
        # self.resb5_3 = BasicBlock(512, 512) #24
        #
        # self.pool5 = nn.MaxPool2d(2, 2, ceil_mode=True)
        #
        # self.resb6_1 = BasicBlock(512,512,dilation=2)
        # self.resb6_2 = BasicBlock(512,512,dilation=2)
        # self.resb6_3 = BasicBlock(512,512,dilation=2) #12
        # self.mulfu = MultiScaleFusion(dim_in=512,
        #                  dim_out=512,
        #                  rate=1,
        #                  bn_mom=0.0003)
        #
        #
        # self.conv6d_1 = nn.Conv2d(1024,512,3,padding=1) # 24
        # self.bn6d_1 = SynchronizedBatchNorm2d(512)
        # self.relu6d_1 = nn.ReLU(inplace=True)
        #
        # self.conv6d_m = nn.Conv2d(512,512,3,dilation=2, padding=2)###
        # self.bn6d_m = SynchronizedBatchNorm2d(512)
        # self.relu6d_m = nn.ReLU(inplace=True)
        #
        # self.conv6d_2 = nn.Conv2d(512,512,3,dilation=2, padding=2)
        # self.bn6d_2 = SynchronizedBatchNorm2d(512)
        # self.relu6d_2 = nn.ReLU(inplace=True)
        #
        # self.conv5d_1 = nn.Conv2d(1024,512,3,padding=1) # 24
        # self.bn5d_1 = SynchronizedBatchNorm2d(512)
        # self.relu5d_1 = nn.ReLU(inplace=True)
        #
        # self.conv5d_m = nn.Conv2d(512,512,3,padding=1)###
        # self.bn5d_m = SynchronizedBatchNorm2d(512)
        # self.relu5d_m = nn.ReLU(inplace=True)
        #
        # self.conv5d_2 = nn.Conv2d(512,512,3,padding=1)
        # self.bn5d_2 = SynchronizedBatchNorm2d(512)
        # self.relu5d_2 = nn.ReLU(inplace=True)

        ## -------------Decoder--------------
        # self.conv4d_1 = nn.Conv2d(1024,512,3,padding=1) # 48
        # self.bn4d_1 = SynchronizedBatchNorm2d(512)
        # self.relu4d_1 = nn.ReLU(inplace=True)
        #
        # self.conv4d_m = nn.Conv2d(512,512,3,padding=1)###
        # self.bn4d_m = SynchronizedBatchNorm2d(512)
        # self.relu4d_m = nn.ReLU(inplace=True)
        #
        # self.conv4d_2 = nn.Conv2d(512,256,3,padding=1)
        # self.bn4d_2 = SynchronizedBatchNorm2d(256)
        # self.relu4d_2 = nn.ReLU(inplace=True)
        #
        # self.conv3d_1 = nn.Conv2d(512,256,3,padding=1) # 96
        # self.bn3d_1 = SynchronizedBatchNorm2d(256)
        # self.relu3d_1 = nn.ReLU(inplace=True)
        #
        # self.conv3d_m = nn.Conv2d(256,256,3,padding=1)###
        # self.bn3d_m = SynchronizedBatchNorm2d(256)
        # self.relu3d_m = nn.ReLU(inplace=True)
        #
        # self.conv3d_2 = nn.Conv2d(256,128,3,padding=1)
        # self.bn3d_2 = SynchronizedBatchNorm2d(128)
        # self.relu3d_2 = nn.ReLU(inplace=True)
        #
        #
        # self.conv2d_1 = nn.Conv2d(256,128,3,padding=1) # 192
        # self.bn2d_1 = SynchronizedBatchNorm2d(128)
        # self.relu2d_1 = nn.ReLU(inplace=True)
        #
        # self.conv2d_m = nn.Conv2d(128,128,3,padding=1)###
        # self.bn2d_m = SynchronizedBatchNorm2d(128)
        # self.relu2d_m = nn.ReLU(inplace=True)
        #
        # self.conv2d_2 = nn.Conv2d(128,64,3,padding=1)
        # self.bn2d_2 = SynchronizedBatchNorm2d(64)
        # self.relu2d_2 = nn.ReLU(inplace=True)
        #
        # self.conv1d_1 = nn.Conv2d(128,64,3,padding=1) # 384
        # self.bn1d_1 = SynchronizedBatchNorm2d(64)
        # self.relu1d_1 = nn.ReLU(inplace=True)
        #
        # self.conv1d_m = nn.Conv2d(64,64,3,padding=1)###
        # self.bn1d_m = SynchronizedBatchNorm2d(64)
        # self.relu1d_m = nn.ReLU(inplace=True)
        #
        # self.conv1d_2 = nn.Conv2d(64,64,3,padding=1)
        # self.bn1d_2 = SynchronizedBatchNorm2d(64)
        # self.relu1d_2 = nn.ReLU(inplace=True)
        #
        # ## -------------Bilinear Upsampling--------------
        self.upscore6 = nn.Upsample(scale_factor=32,mode='bilinear',align_corners=False)###
        self.upscore5 = nn.Upsample(scale_factor=16,mode='bilinear',align_corners=False)
        self.upscore4 = nn.Upsample(scale_factor=8,mode='bilinear',align_corners=False)
        self.upscore3 = nn.Upsample(scale_factor=4,mode='bilinear',align_corners=False)
        # self.upscore2 = nn.Upsample(scale_factor=2, mode='bilinear',align_corners=False)
        #
        # ## -------------Side Output--------------
        # self.outconvb = nn.Conv2d(512,n_classes,3,padding=1) #n_classes
        # self.outconv6 = nn.Conv2d(512,n_classes,3,padding=1)
        # self.outconv5 = nn.Conv2d(512,n_classes,3,padding=1)
        # self.outconv4 = nn.Conv2d(256,n_classes,3,padding=1)
        # self.outconv3 = nn.Conv2d(128,128,3,padding=1)  #
        # self.outconv2 = nn.Conv2d(64,n_classes,3,padding=1)
        # self.outconv1 = nn.Conv2d(64,n_classes,3,padding=1)
        #
        # self.input = nn.Conv2d(3, 3, 2, padding=0)
        # self.ndf = nn.Conv2d(128, 1, 1, padding=0)
        # self.bn1 = nn.BatchNorm2d(1, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        # self.bn2 = nn.BatchNorm2d(1)
        # self.bn3 = nn.BatchNorm2d(1)
        # self.bn4 = nn.BatchNorm2d(1)
        # self.bn5 = nn.BatchNorm2d(1)
        # self.bn6 = nn.BatchNorm2d(1)
        # self.bn7 = nn.BatchNorm2d(1)
        # self.bn8 = nn.BatchNorm2d(1)
        # self.relu1 = ReLU()
        ## -------------Refine Module-------------
        self.diffnet = DiffNet(n_classes,256) #n_classes
        self.backbone = {'b4': mit_b4}['b4'](True)
        self.decode_head = SegFormerHead(1, [64, 128, 320, 512], 256, 0.1)
        self.conv_seg_fd0 = nn.Conv2d(64, n_classes, kernel_size=1)
        self.conv_seg_fd1 = nn.Conv2d(128, n_classes, kernel_size=1)
        self.conv_seg_fd2 = nn.Conv2d(320, n_classes, kernel_size=1)
        self.conv_seg_fd3 = nn.Conv2d(512, n_classes, kernel_size=1)
        self.conv_seg_fd0_uda = nn.Conv2d(64, 2, kernel_size=1)
        self.conv_seg_fd1_uda = nn.Conv2d(128, 2, kernel_size=1)
        self.conv_seg_fd2_uda = nn.Conv2d(320, 2, kernel_size=1)
        self.conv_seg_fd3_uda = nn.Conv2d(512, 2, kernel_size=1)
        self.conv_seg = nn.Conv2d(256, 1, kernel_size=1)


    def forward(self,x):

        hx = x  # 6,3,321,321
        hx = t_resize(hx)

        ## -------------Encoder-------------
        out = []
        x = self.backbone.forward(hx)
        #torch.Size([2, 64, 96, 96]) ([2, 128, 48, 48]) ([2, 320, 24, 24]) ([2, 512, 12, 12])
        x0 = self.upscore3(x[0])
        x0_loss = self.conv_seg_fd0(x0)
        x0_uda = self.conv_seg_fd0_uda(x0)
        x1 = self.upscore4(x[1])
        x1_loss = self.conv_seg_fd1(x1)
        x1_uda = self.conv_seg_fd1_uda(x1)
        x2 = self.upscore5(x[2])
        x2_loss = self.conv_seg_fd2(x2)
        x2_uda = self.conv_seg_fd2_uda(x2)
        x3 = self.upscore6(x[3])
        x3_loss = self.conv_seg_fd3(x3)
        x3_uda = self.conv_seg_fd3_uda(x3)
        out.append(x0_loss)
        out.append(x1_loss)
        out.append(x2_loss)
        out.append(x3_loss)
        x = self.decode_head.forward(x) #torch.Size([2, 256, 96, 96])
        x = self.upscore3(x) #([2, 256, 384, 384])
        x4 = self.conv_seg(x)

        out.append(x4)
        out.append(x0_uda)
        out.append(x1_uda)
        out.append(x2_uda)
        out.append(x3_uda)
        x = self.conv_seg(x) #([2, 1, 384, 384])
        x = self.diffnet(x)

        return torch.sigmoid(x), torch.sigmoid(out[0]), torch.sigmoid(out[1]), torch.sigmoid(out[2]), torch.sigmoid(out[3]), torch.sigmoid(out[4]), torch.sigmoid(out[5]),torch.sigmoid(out[6]),torch.sigmoid(out[7]),torch.sigmoid(out[8])
if __name__=="__main__":
    a = torch.randn(1,3,321,321)
    print(a)
    net = BoundaryNets(3, 1)
    module = net(a)
    print(module[0])