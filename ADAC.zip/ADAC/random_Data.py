import os, random, shutil

def moveFile(fileDir):
    pathDir = os.listdir(fileDir)
    filenumber = len(pathDir)
    print(filenumber)

    rate = 0.2
    picknumber = 500
    sample = random.sample(pathDir, picknumber)
    print(sample)
    for name in sample:
        if '.tif' in name:
            shutil.move(fileDir2 + name[:-4] + '.png', tarDir2 + name[:-4] + '.png')
            shutil.move(fileDir + name, tarDir + name)
    return

if __name__=="__main__":
    fileDir = r'/media/xk/DATA/wdcd/fly_dataset/landsat_precent/val/'
    fileDir2 = r'/media/xk/DATA/wdcd/fly_dataset/landsat_precent/val_label/'

    tarDir = r'/media/xk/DATA/wdcd/fly_dataset/landsat_precent/TFtest/'
    tarDir2 = r'/media/xk/DATA/wdcd/fly_dataset/landsat_precent/TFtest_label/'
    moveFile(fileDir)

