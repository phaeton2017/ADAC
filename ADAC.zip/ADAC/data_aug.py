import math
import os
import random
import h5py
import numpy as np
import torch
from scipy import ndimage
from scipy.ndimage.interpolation import zoom
from torch.utils.data import Dataset
from PIL import Image, ImageChops
from PIL import ImageEnhance
from PIL import ImageFilter
import os
import cv2
import numpy as np
"""
水平翻转、随机旋转、颜色扰动、对比度增强、亮度增强、颜色增强、平移、随机裁剪
本代码共采用了四种数据增强，如采用其他数据增强方式，可以参考本代码，随意替换。
imageDir 为原数据集的存放位置
saveDir  为数据增强后数据的存放位置
1、水平翻转
2、随机旋转角度
3、颜色扰动
4、对比度增强
5、亮度增强
6、平移             # 可能没用
7、随机裁剪
8、水平翻转+随机旋转
9、水平翻转+随机旋转+颜色扰动
13、水平翻转+随机旋转+随机裁剪
10、水平翻转+随机旋转+随机裁剪+颜色扰动
11、水平翻转+随机旋转+随机裁剪+亮度增强
12、水平翻转+随机旋转+随机裁剪+对比度增强
"""
def aug12(image_path, label_path):
    image, label = aug13(image_path, label_path)
    enh_con = ImageEnhance.Contrast(image)
    contrast = 1.5
    image_contrasted = enh_con.enhance(contrast)
    return image_contrasted, label

def aug11(image_path, label_path):
    image, label = aug13(image_path, label_path)
    random_factor = np.random.randint(0, 31) / 10.  # 随机因子
    color_image = ImageEnhance.Color(image).enhance(random_factor)  # 调整图像的饱和度
    random_factor = np.random.randint(10, 21) / 10.  # 随机因子
    brightness_image = ImageEnhance.Brightness(color_image).enhance(random_factor)  # 调整图像的亮度
    random_factor = np.random.randint(10, 21) / 10.  # 随机因子
    contrast_image = ImageEnhance.Contrast(brightness_image).enhance(random_factor)  # 调整图像对比度
    random_factor = np.random.randint(0, 31) / 10.  # 随机因子
    return ImageEnhance.Sharpness(contrast_image).enhance(random_factor), label  # 调整图像锐度
def aug13(image_path, label_path):
    image, label = aug8(image_path, label_path)
    image_width = image.size[0]
    image_height = image.size[1]
    crop_image_width = math.ceil(image_width * 2 / 3)
    crop_image_height = math.ceil(image_height * 2 / 3)
    x = np.random.randint(0, image_width - crop_image_width)
    y = np.random.randint(0, image_height - crop_image_height)
    random_region = (x, y, x + crop_image_width, y + crop_image_height)
    img, lbl = image.crop(random_region), label.crop(random_region)
    img, lbl = np.array(img), np.array(lbl)
    img = cv2.resize(img, (image_width, image_height), interpolation=cv2.INTER_CUBIC)
    lbl = cv2.resize(lbl, (image_width, image_height), interpolation=cv2.INTER_CUBIC)
    img, lbl = Image.fromarray(img), Image.fromarray(lbl)
    return img, lbl

def aug10(image_path, label_path):
    image, label = aug9(image_path, label_path)
    image_width = image.size[0]
    image_height = image.size[1]
    crop_image_width = math.ceil(image_width * 2 / 3)
    crop_image_height = math.ceil(image_height * 2 / 3)
    x = np.random.randint(0, image_width - crop_image_width)
    y = np.random.randint(0, image_height - crop_image_height)
    random_region = (x, y, x + crop_image_width, y + crop_image_height)
    img, lbl = image.crop(random_region), label.crop(random_region)
    img, lbl = np.array(img), np.array(lbl)
    img = cv2.resize(img, (image_width, image_height), interpolation=cv2.INTER_CUBIC)
    lbl = cv2.resize(lbl, (image_width, image_height), interpolation=cv2.INTER_CUBIC)
    img, lbl = Image.fromarray(img), Image.fromarray(lbl)
    return img, lbl

def aug9(image_path, label_path):
    image, label = aug8(image_path, label_path)
    random_factor = np.random.randint(0, 31) / 10.  # 随机因子
    color_image = ImageEnhance.Color(image).enhance(random_factor)  # 调整图像的饱和度
    random_factor = np.random.randint(10, 21) / 10.  # 随机因子
    brightness_image = ImageEnhance.Brightness(color_image).enhance(random_factor)  # 调整图像的亮度
    random_factor = np.random.randint(10, 21) / 10.  # 随机因子
    contrast_image = ImageEnhance.Contrast(brightness_image).enhance(random_factor)  # 调整图像对比度
    random_factor = np.random.randint(0, 31) / 10.  # 随机因子
    return ImageEnhance.Sharpness(contrast_image).enhance(random_factor), label  # 调整图像锐度
# 水平翻转+随机旋转
def aug8(image_path, label_path):
    img, label = flip(image_path, label_path)
    k = random.randint(-90, 90)
    rotation_img = img.rotate(k)
    rotaton_label = label.rotate(k)
    return rotation_img, rotaton_label
# 裁剪
def randomCrop(image_path, label_path):
    image = Image.open(image_path).convert('L')
    label = Image.open(label_path)
    image_width = image.size[0]
    image_height = image.size[1]
    crop_image_width = math.ceil(image_width*2/3)
    crop_image_height = math.ceil(image_height*2/3)
    x = np.random.randint(0, image_width - crop_image_width)
    y = np.random.randint(0, image_height - crop_image_height)
    random_region = (x, y, x + crop_image_width, y + crop_image_height)
    img, lbl = image.crop(random_region), label.crop(random_region)
    img, lbl = np.array(img), np.array(lbl)
    img = cv2.resize(img, (image_width, image_height), interpolation=cv2.INTER_CUBIC)
    lbl = cv2.resize(lbl, (image_width, image_height), interpolation=cv2.INTER_CUBIC)
    img, lbl = Image.fromarray(img), Image.fromarray(lbl)
    return img, lbl
#平移，平移尺度为off
def move(image_path, label_path):
    img = Image.open(image_path).convert('L')
    lbl = Image.open(label_path)
    x = random.randint(0, 200)
    y = random.randint(0, 200)
    offset = ImageChops.offset(img, x, y)
    offset_lbl = ImageChops.offset(lbl, x, y)
    return offset, offset_lbl
 #  翻转图像
def flip(image_path, label_path):
    img = Image.open(image_path).convert('L')
    label = Image.open(label_path)
    filp_img = img.transpose(Image.FLIP_LEFT_RIGHT)
    flip_label = label.transpose(Image.FLIP_LEFT_RIGHT)
    return filp_img, flip_label
#旋转角度
def rotation(image_path, label_path):
    img = Image.open(image_path).convert('L')
    label = Image.open(label_path)
    k = random.randint(-90, 90)
    rotation_img = img.rotate(k)
    rotaton_label = label.rotate(k)
    return rotation_img, rotaton_label
#随机颜色
def randomColor(image_path, label_path):
    """
    对图像进行颜色抖动
    :param image: PIL的图像image
    :return: 有颜色色差的图像image
    """
    image = Image.open(image_path).convert('L')
    label = Image.open(label_path)
    random_factor = np.random.randint(0, 31) / 10.  # 随机因子
    color_image = ImageEnhance.Color(image).enhance(random_factor)  # 调整图像的饱和度
    random_factor = np.random.randint(10, 21) / 10.  # 随机因子
    brightness_image = ImageEnhance.Brightness(color_image).enhance(random_factor)  # 调整图像的亮度
    random_factor = np.random.randint(10, 21) / 10.  # 随机因子
    contrast_image = ImageEnhance.Contrast(brightness_image).enhance(random_factor)  # 调整图像对比度
    random_factor = np.random.randint(0, 31) / 10.  # 随机因子
    return ImageEnhance.Sharpness(contrast_image).enhance(random_factor), label  # 调整图像锐度
 # 对比度增强
def contrastEnhancement(image_path, label_path):
    image = Image.open(image_path).convert('L')
    label = Image.open(label_path)
    enh_con = ImageEnhance.Contrast(image)
    contrast = 1.5
    image_contrasted = enh_con.enhance(contrast)
    return image_contrasted, label
# 亮度增强
def brightnessEnhancement(image_path, label_path):
    image = Image.open(image_path).convert('L')
    label = Image.open(label_path)
    enh_bri = ImageEnhance.Brightness(image)
    brightness = 1.2
    image_brightened = enh_bri.enhance(brightness)
    return image_brightened, label
# 颜色增强
def colorEnhancement(image_path, label_path):
    image = Image.open(image_path)
    label = Image.open(label_path)
    enh_col = ImageEnhance.Color(image)
    color = 1.5
    image_colored = enh_col.enhance(color)
    return image_colored, label
# 水平翻转
def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    label = np.flip(label, axis=axis).copy()
    return image, label
# 旋转 随机-20——20
def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label

if __name__=='__main__':
    imageDir = "/media/xk/新加卷1/dataset/medical_all/good_image/origin/"  # 要改变的图片的路径文件夹
    labelDir = "/media/xk/新加卷1/dataset/medical_all/good_mask/origin/"
    saveDir_img = "/media/xk/新加卷1/dataset/medical_all/good_image/aug12/"  # 要保存的图片的路径文件夹
    saveDir_lbl = "/media/xk/新加卷1/dataset/medical_all/good_mask/aug12/"
    list_patientName = os.listdir(imageDir)
    for patientName in list_patientName:
        for name in os.listdir(imageDir+patientName):
            # 水平翻转
            img_path = imageDir + patientName + '/' + name
            lbl_path = labelDir + patientName + '/' + name
            saveName = name[:-4] + "_fl.jpg"
            img_save_path = saveDir_img + patientName + '/' + saveName
            lbl_save_path = saveDir_lbl + patientName + '/' + saveName
            if not os.path.exists(saveDir_img+ patientName + '/'):
                os.makedirs(saveDir_img+ patientName + '/')
                print(saveDir_img+ patientName + '/' + '创建成功！')
            if not os.path.exists(saveDir_lbl+ patientName + '/'):
                os.makedirs(saveDir_lbl+ patientName + '/')
                print(saveDir_lbl + patientName + '/' + '创建成功！')
            saveImage, saveLabel = aug12(img_path, lbl_path)
            saveImage.save(img_save_path)
            saveLabel.save(lbl_save_path)

        # saveName = name[:-4] + "ro.jpg"
        # saveImage = rotation(imageDir, name)
        # saveImage.save(os.path.join(saveDir, saveName))
