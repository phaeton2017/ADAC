import os
import random
import re
path = '/media/xk/WD_BLACK/218/landsat7'
#
# for i in range(len(next(os.walk(path))[1])):
#     path_list = next(os.walk(path))[1][i]
#     path2 = path + '/' + path_list
#     #print(path2)
#     picture = os.listdir(path2)
#     for filename in picture:
#         #filename = filename[:21]
#         path_list_change = filename
#         # if 'B1' in filename:
#         #     b1name = filename
#         #     b1name_change = path_list[:21] + '_B1.TIF'
#         #     print(b1name_change)
#         #     srcpath = os.path.join(path2, b1name)
#         #     allpath = os.path.join(path2, b1name_change)
#         #     os.rename(srcpath, allpath)
#         #     #print(srcpath,allpath)
#         # if 'B2' in filename:
#         #     b2name = filename
#         #     b2name_change = path_list[:21] + '_B2.TIF'
#         #     print(b2name_change)
#         #     srcpath = os.path.join(path2, b2name)
#         #     allpath = os.path.join(path2, b2name_change)
#         #     os.rename(srcpath, allpath)
#         #     #print(srcpath,allpath)
#         # if 'B3' in filename:
#         #     b3name = filename
#         #     b3name_change = path_list[:21] + '_B3.TIF'
#         #     print(b3name_change)
#         #     srcpath = os.path.join(path2, b3name)
#         #     allpath = os.path.join(path2, b3name_change)
#         #     os.rename(srcpath, allpath)
#         #     #print(srcpath,allpath)
#
#
#         #srcpath = os.path.join(path, path_list)
#         #allpath = os.path.join(path, path_list_change)
#         #os.rename(srcpath, allpath)
#         #print(srcpath,allpath)
#         #break
#
# exit()
#
# def changename(orignname):
#     picture = os.listdir(orignname)
#     for filename in picture:
#         # filename1 = filename.split(".")[0]
#         # filename2=re.findall(r"\d+\.?\d*", filename1)[0]+".png"
#        # srcpath = os.path.join(orignname,filename)
#         #allpath = os.path.join(orignname,filename2)
#         # os.rename(srcpath,allpath)
#         if "2.tif" in filename:
#
#             print(filename[:-5]+"2labeled.tif")
#             filename1=filename[:-5]+"2labeled.tif"
#             srcpath = os.path.join(orignname, filename)
#             allpath = os.path.join(orignname, filename1)
#             os.rename(srcpath, allpath)
#
#         # split("_",2)[1]    “_”表示分隔符 ; 2表示分割次数 ; [1]表示选取第 i 个片段
#         #filename1 = filename.split("_")[3]
#         # 设置旧文件名（就是路径+文件名）
#         #srcpath = os.path.join(orignname, filename)
#         # 设置新文件名
#         #allpath = os.path.join(orignname, filename1)
#         #os.rename(srcpath, allpath)
#
#
# if __name__ == '__main__':
#     orignname = r"/media/xk/home/wwxDatasetAll/bounddata/labelsGT"
#     changename(orignname)

folder_path = '/media/xk/新加卷1/wwxdata/clouddata/sentinel-2/l8/select_all/image'
# n = 250
file_name = os.listdir(folder_path)
# selected_files = random.sample(file_name, n)

# with open('/media/xk/新加卷1/wwxdata/clouddata/sentinel-2/S2/train.txt', 'r') as file:
#     lines = file.readlines()
# for i in range(250):
#     random_line = random.choice(lines)
#     line_number = lines.index(random_line) + 1
#     print(line_number, random_line.strip())
#     lines[line_number-1] = random_line[:-4] + '_labeled.tif' + '\n'
#     with open('/media/xk/新加卷1/wwxdata/clouddata/sentinel-2/S2/train.txt', 'w') as file:
#         file.writelines(lines)

    # for file in selected_files:
    #     file_name_edi = file[:-4] + '_labeled.tif'
    #     print(file_name_edi)
    # for line in file:
    #     print(0,line)
    #     # print(selected_files)
    #     for n in range(250):
    #         if line == selected_files[n]:
    #             file_name_edi = line[:-4] + '_labeled.tif'
    #             print(1, file_name_edi)
    # # for file in selected_files:
    # #     file_name_edi = file[:-4] + '_labeled.tif'
#     # #     print(file_name_edi)
with open('/media/xk/新加卷1/wwxdata/clouddata/sentinel-2/l8/select_all/train.txt', 'w') as file:
    # lines = file.readlines()
    for name in file_name:
        file.write(name + "\n")

