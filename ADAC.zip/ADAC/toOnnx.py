import torch
from model import BoundaryNets

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

net = BoundaryNets(3, 1)
checkpoint = torch.load('/home/xk/PycharmProjects/boundary-nets-master_new/save_models_uda/epoch65_boundarynets_bsi_itr_74790_train_2.936626_tar_0.263847.pth')
net.load_state_dict(checkpoint['model_state_dict'])
# net.load_state_dict(torch.load(r'/home/xk/PycharmProjects/boundary-nets-master_new/save_models_uda/epoch65_boundarynets_bsi_itr_74790_train_2.936626_tar_0.263847.pth'), device)
net.eval()

example = torch.ones(1,3,321,321)
torch.onnx.export(net, example, "model_vis.onnx", verbose=True, opset_version=11)