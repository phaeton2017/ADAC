# coding = utf-8

import os
import datetime
import time
import torch
from PIL import Image
from matplotlib import pyplot as plt
# import torchvision
from sklearn import metrics
from sklearn.svm._libsvm import predict
from torch.autograd import Variable
import torch.nn as nn
# import torch.nn.functional as F
from torch.backends import cudnn
from tensorboardX import SummaryWriter
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
from torchvision.transforms import Resize
import torch.optim as optim
# import torchvision.transforms as standard_transforms
import random
import numpy as np
# import glob
# import pandas as pd
# from sklearn.metrics import precision_score
from boundarynets_test_sparcs import normPRED
from data_loader_SPARCS import ToTensorNorm, CloudDataset

from model import BoundaryNets
# from joint_trainsform import RandomHorizontallyFlip # , RandomRotate, RandomGaussianBlur
# from utils import clip_gradient, adjust_lr

# for visualDL
# from PIL import Image
# from visualdl import LogWriter

import pytorch_iou.iou_loss

from model.sync_batchnorm.replicate import patch_replication_callback
from model.utils.visualization import subplotimg

# ------- 0. define rely function --------
# enable cudnn accelerate
# torch.backends.cudnn.benchmark = True
# set the GPU id
from splitfeature import Split_feature_discriminator_4

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

t_resize = Resize([384, 384])
# define the global seed
def save_output(image_name, pred, d_dir,OA):
    predict = pred
    predict = predict.squeeze()
    predict_np = (predict * 255).astype(np.uint8)
    # print("SAVE", predict_np)
    # print(predict_np.shape)
    # color_file = Image.fromarray(colorize(predict_np).transpose(1, 2, 0), 'RGB')
    im = Image.fromarray(predict_np).convert('RGB')
    #im.show()
    # img = Image.fromarray(colorize(color_file).transpose(1, 2, 0), 'RGB')
    im.save(d_dir + '/' + image_name[:-6] + "_%3f" % (OA) +'.png')

def set_seed(seed = 20210313):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    cudnn.deterministic = True
    # cudnn.benchmark = False
    # cudnn.enabled = False

def _init_fn(worker_id):
    random.seed(10 + worker_id)
    np.random.seed(10 + worker_id)
    torch.manual_seed(10 + worker_id)
    torch.cuda.manual_seed(10 + worker_id)
    torch.cuda.manual_seed_all(10 + worker_id)

# make sure the path exisits
def ensure_dir(dir_path):
    if not os.path.isdir(dir_path):
        os.makedirs(dir_path)


# ------- 1. define loss function --------
criterion = nn.BCELoss()
# bce_loss = nn.BCELoss(size_average=True)
bce_loss = nn.BCELoss(size_average=True)#
iou_loss = pytorch_iou.IOU(size_average=True)

def dl_loss(pred, target):
    
    bce_out = bce_loss(pred, target)
    iou_out = iou_loss(pred, target)

    loss = bce_out + iou_out
    
    return loss
    

def muti_loss_fusion(d0, d1, d2, d3, d4, d5, labels_v):
    loss0 = dl_loss(d0, labels_v)
    loss1 = dl_loss(d1, labels_v)
    loss2 = dl_loss(d2, labels_v)
    loss3 = dl_loss(d3, labels_v)
    loss4 = dl_loss(d4, labels_v)
    loss5 = dl_loss(d5, labels_v)
    # loss6 = dl_loss(d6, labels_v)
    # loss7 = dl_loss(d7, labels_v)
    
    
    loss = loss0 + loss1 + loss2 + loss3 + loss4 + loss5
    
    return loss0, loss

def lr_poly(base_lr, iter, max_iter, power):
    return base_lr*((1-float(iter)/max_iter)**(power))
def adjust_learning_rate_D(optimizer, epoch):
    lr = lr_poly(learning_rate_D, epoch, epoch_num, power)
    optimizer.param_groups[0]['lr'] = lr
    if len(optimizer.param_groups) > 1:
        optimizer.param_groups[1]['lr'] = lr * 10



# ------- 2. set the train details --------
setup_seed(2022)

# train details
start_epoch = 0
epoch_num = 200
batch_size_train = 2
batch_size_target = 2
batch_size_val = 1

save_interval_epoch = 1
valid_epoch = 1

learning_rate = 2.5e-5
learning_rate_D = 1e-5

power = 0.9
weight_decay = 0.0005
momentum = 0.9


if __name__ == '__main__':
    is_resume_train = True
    # path_checkpoint = '/media/xk/新加卷/code/boundarynet/4uda_410/savemodels_4dua/' #/media/xk/新加卷/code/boundarynet/savemodels_lrNEW8uda/"
    # Writer =SummaryWriter('/media/xk/新加卷/code/boundarynet/4uda_410/summarywriter_4dua_55/') #('/media/xk/新加卷/code/boundarynet/summarywriter_lr8uda')
    # model_dir = '/media/xk/新加卷/code/boundarynet/4uda_410/savemodels_4dua/' #"/media/xk/新加卷/code/boundarynet/savemodels_lrNEW8uda/"
    path_checkpoint = r'E:/code/boundarynet/4uda_410/savemodels_4dua/' #/media/xk/新加卷/code/boundarynet/savemodels_lrNEW8uda/"
    Writer =SummaryWriter(r'E:/code/boundarynet/4uda_410/summarywriter_4dua_55/') #('/media/xk/新加卷/code/boundarynet/summarywriter_lr8uda')
    model_dir = r'E:/code/boundarynet/4uda_410/savemodels_4dua/' #"/media/xk/新加卷/code/boundarynet/savemodels_lrNEW8uda/"

    ensure_dir(model_dir)


    # ------- 3. load the train dataset --------
    train_txt = r'D:/wwxdata/cloud_source/train.txt' #"/media/xk/新加卷1/wwxdata/cloud_source/train.txt"
    # train_txt = "/media/xk/新加卷1/wwxdata/cloud_source/train.txt"
    with open(train_txt, 'r',encoding='utf-8') as f:
        train_list = f.readlines()

    target_list = []
    target_txt = r'D:/wwxdata/cloud_target/train.txt' #"/media/xk/新加卷/code/DAFormer-master/data/cloud_target/train.txt"
    # target_txt = '/media/xk/新加卷1/wwxdata/cloud_target/train.txt'
    with open(target_txt, 'r',encoding='utf-8') as f:
        target_list = f.readlines()

    valid_list = []
    valid_txt = r'D:/wwxdata/cloud_target/val.txt'
    # valid_txt = '/media/xk/新加卷1/wwxdata/cloud_target/val.txt' #"/media/xk/新加卷/code/DAFormer-master/data/cloud_target/train.txt"
    with open(valid_txt, 'r',encoding='utf-8') as f:
        valid_list = f.readlines()


    train_num = len(train_list)
    tg_num = len(target_list)
    valid_num = len(valid_list)

    print("---")
    print("train images: ", len(train_list))
    print("target images: ", len(target_list))
    print("valid images: ", len(valid_list))
    print("---")

    ## for train
    salobj_dataset = CloudDataset(
        file_name_list=train_list,
        transform=transforms.Compose([
            ToTensorNorm(),
            # RandomHorizontallyFlip(),
        ]),test_mode=0)
    salobj_dataloader = DataLoader(salobj_dataset, batch_size=batch_size_train, shuffle=True, num_workers=4)

    dataset_target = CloudDataset(
        file_name_list=target_list,
        transform=transforms.Compose([
            ToTensorNorm(),
            # RandomHorizontallyFlip(),
        ]), test_mode=1)
    dataset_target_dataloader = DataLoader(dataset_target, batch_size=batch_size_target, shuffle=True, num_workers=4, worker_init_fn=_init_fn)
    # dataset_target_dataloader_iter = iter(dataset_target_dataloader)
    ## for valid
    valid_target = CloudDataset(
        file_name_list=valid_list,
        transform=transforms.Compose([
            ToTensorNorm(),
            # RandomHorizontallyFlip(),
        ]), test_mode=2)
    valid_target_dataloader = DataLoader(valid_target, batch_size=batch_size_val, shuffle=True, num_workers=4, worker_init_fn=_init_fn)
    # ------- 4. define model --------
    # define the net
    net = BoundaryNets(3, 1)
    if torch.cuda.is_available():
        if len(os.environ["CUDA_VISIBLE_DEVICES"].split(",")) >1:
            net = nn.DataParallel(net)
            patch_replication_callback(net)
        net = net.cuda()
    # init D1
    model_D1 = Split_feature_discriminator_4(layer_name='layer1')
    model_D1.train()
    model_D1.cuda()
    # init D01
    model_D01 = Split_feature_discriminator_4(layer_name='layer1')
    model_D01.train()
    model_D01.cuda()
    # init D02
    model_D02 = Split_feature_discriminator_4(layer_name='layer1')
    model_D02.train()
    model_D02.cuda()
    # init D11
    model_D11 = Split_feature_discriminator_4(layer_name='layer1')
    model_D11.train()
    model_D11.cuda()
    # init D12
    model_D12 = Split_feature_discriminator_4(layer_name='layer1')
    model_D12.train()
    model_D12.cuda()
    # init D21
    model_D21 = Split_feature_discriminator_4(layer_name='layer1')
    model_D21.train()
    model_D21.cuda()
    # init D22
    model_D22 = Split_feature_discriminator_4(layer_name='layer1')
    model_D22.train()
    model_D22.cuda()
    # init D31
    model_D31 = Split_feature_discriminator_4(layer_name='layer1')
    model_D31.train()
    model_D31.cuda()
    # init D32
    model_D32 = Split_feature_discriminator_4(layer_name='layer1')
    model_D32.train()
    model_D32.cuda()
    # ------- 5. define optimizer --------
    print("---define optimizer...")

    # optimizer for segmentation network
    optimizer = optim.SGD(net.parameters(),
                          lr=learning_rate, momentum=momentum, weight_decay=weight_decay)
    optimizer.zero_grad()

    optimizer_D1 = optim.Adam(model_D1.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D1.zero_grad()

    optimizer_D01 = optim.Adam(model_D01.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))  #
    optimizer_D01.zero_grad()
    optimizer_D02 = optim.Adam(model_D02.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D02.zero_grad()
    optimizer_D11 = optim.Adam(model_D11.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D11.zero_grad()
    optimizer_D12 = optim.Adam(model_D12.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D12.zero_grad()
    optimizer_D21 = optim.Adam(model_D21.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D21.zero_grad()
    optimizer_D22 = optim.Adam(model_D22.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D22.zero_grad()
    optimizer_D31 = optim.Adam(model_D31.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D31.zero_grad()
    optimizer_D32 = optim.Adam(model_D32.parameters(), lr=learning_rate_D, betas=(0.9, 0.99))
    optimizer_D32.zero_grad()


    # ------- 6. training process --------
    # load the resume train param
    if is_resume_train:
        checkpoint = torch.load(r'E:/code/boundarynet/4uda_410/savemodels_4dua/epoch11_boundarynets_bsi_itr_11276ssScr2.687233_lossTGT_0.000000.pth')#'/media/xk/新加卷/code/boundarynet/savemodels_lrNEW8uda/epoch2_boundarynets_bsi_itr_14264ssScr4.652960_lossTGT_0.000000.pth')
        net.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optim_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
    print(start_epoch)
    print("---start training...")
    print("Start time:" + str(datetime.datetime.now().strftime('%y-%m-%d %H:%M:%S')))

    ite_num = 0
    running_loss = 0.0
    running_gt_loss = 0.0
    ite_num4val = 0
    iter_valid_all = 0


    valid_loss = 0.0
    valid_target_loss = 0.0
    loss_ada = 0.0
    loss_adapt31 = 0.0
    loss_adapt32 = 0.0
    loss_adapt1 = 0.0
    loss_D31 = 0.0
    loss_D32 = 0.0
    loss_D31 = 0.0
    loss_D = 0.0

    train_start_time = time.time()
    time_for_each_epoch = []

    for epoch in range(start_epoch, start_epoch+epoch_num):
        if (epoch + 1) % valid_epoch == 0:
            print('start valid')
            acc_valid = 0
            iter_valid = 0
            running_loss_valid = 0.0
            for i, data_valid in enumerate(valid_target_dataloader):
                # for i, data_scr in enumerate(salobj_dataloader):
                iter_valid = iter_valid + 1
                iter_valid_all = iter_valid_all + 1

                inputs, labels = data_valid['image'], data_valid['mask']

                inputs = inputs.type(torch.FloatTensor)
                labels = labels.type(torch.FloatTensor)

                # wrap them in Variable
                if torch.cuda.is_available():
                    inputs_valid, labels_valid = Variable(inputs.cuda(), requires_grad=False), Variable(labels.cuda(),
                                                                                                        requires_grad=False)
                else:
                    inputs_valid, labels_valid = Variable(inputs, requires_grad=False), Variable(labels,
                                                                                                 requires_grad=False)

                v0, d1, d2, d3, d4, d5, d6, d7, d8, d9 = net(inputs_valid)

                labels_valid = t_resize(labels_valid)
                loss_valid, _ = muti_loss_fusion(v0, d1, d2, d3, d4, d5, labels_valid)
                running_loss_valid += loss_valid.data.item()

                true_label = labels_valid.data.cpu().numpy()
                validlabel = true_label
                validlabel = validlabel.reshape(1, 384, 384)

                true_label = true_label.flatten()
                true_label = true_label.astype("int")
                # end

                # print(d1.shape)
                pred = v0[:, 0, :, :]
                # print(pred)

                # pred = F.log_softmax(pred)
                # print(pred)

                pred = normPRED(pred)

                # print(pred)
                # print(pred.shape)
                pred_np = pred.data.cpu().numpy() * 255
                # print(pred_np)
                # pred_np = pred_np.astype(int)
                # print(pred_np.shape, pred_np.dtype)
                pred_np = pred_np.flatten()
                # print(pred_np)
                for a in range(len(pred_np)):
                    if pred_np[a] > 125.5 and pred_np[a] < 255:
                        pred_np[a] = 1
                    else:
                        pred_np[a] = 0
                # print(pred_np)
                pred_np = pred_np.astype(np.uint8)
                validpred = pred_np.reshape(1, 384, 384)
                # 计算acc

                recall_score = metrics.recall_score(true_label, pred_np, average='macro')  # 召回率
                Precision = metrics.precision_score(true_label, pred_np, average='macro')  # 准确率

                OA = metrics.accuracy_score(true_label, pred_np)
                F1 = metrics.f1_score(true_label, pred_np, average='macro')
                acc_valid = acc_valid + OA

                pred_np = pred_np.reshape((1, 384, 384))
                # pred_np = pred_np.reshape((1, 320, 320)) #ori

                valid_dir = os.path.join(
                    r'E:/code/boundarynet/4uda_410/output_4uda/' + f'{(epoch + 1):04d}')  # ('/media/xk/新加卷/code/boundarynet/outpred_NEW8UDA/' + f'{(epoch + 1):04d}')
                os.makedirs(valid_dir, exist_ok=True)
                out_dir = os.path.join(
                    r'E:/code/boundarynet/4uda_410/valid_4uda/' + f'{(epoch + 1):04d}')
                os.makedirs(out_dir, exist_ok=True)
                # print(data_valid['name'][0])
                image_valid = Image.open(r'D:/wwxdata/' + data_valid['name'][0])

                image_valid_ori = Image.open(
                    r'D:/wwxdata/' + data_valid['name'][0])
                imagename = data_valid['name'][0][24:]
                # print(os.path.join(out_dir, imagename))
                rows, cols = 1, 4
                fig, axs = plt.subplots(
                    rows,
                    cols,
                    figsize=(4 * cols, 4 * rows),
                )
                subplotimg(axs[0], np.asarray(image_valid_ori), 'Image')
                subplotimg(axs[1], np.asarray(image_valid), 'S_Image')
                # print(validlabel.shape)
                subplotimg(axs[2],
                           validlabel,  # gt_semantic_seg[j],
                           'valid label',
                           cmap='cityscapes')
                subplotimg(axs[3],
                           validpred,  # gt_semantic_seg[j],
                           'valid Pred',
                           cmap='cityscapes')

                for ax in axs.flat:
                    ax.axis('off')
                plt.savefig(out_dir+'/' + imagename)
                    # os.path.join(out_dir[:-2]+'/' + imagename))
                plt.close()
                save_output(valid_list[i], pred_np, valid_dir, OA)

                Writer.add_scalar("valid", loss_valid.item(), iter_valid_all)
                Writer.add_scalar("valid_OA", OA, iter_valid_all)

                # save_output(test_list[i_test][10:-4], pred_np, prediction_dir)
                del v0, d1, d2, d3, d4, d5, d6, d7, d8, d9
            # print("[%d / %d]inferencing %s" % (i, maxval, test_list[i_test].split("/")[-1]))

            Writer.add_scalar("valid_epoch", running_loss_valid / len(valid_list), epoch)
            Writer.add_scalar("valid_OA_epoch", acc_valid / len(valid_list), epoch)

            print('valid_OA:', acc_valid / len(valid_list))
            print("epoch%d_valid_OA%f:" % (epoch, acc_valid / len(valid_list)))
        net.train()
        start_time = time.time()
        # optimizer.param_groups[0]['lr'] = 0.01 * (1 - epoch / (epoch_num + 1))
        for i, (data_scr, data_tgt) in enumerate(zip(salobj_dataloader, dataset_target_dataloader)):
        # for i, data_scr in enumerate(salobj_dataloader):
            ite_num = ite_num + 1
            ite_num4val = ite_num4val + 1

            inputs, labels = data_scr['image'], data_scr['mask']

            inputs = inputs.type(torch.FloatTensor)
            labels = labels.type(torch.FloatTensor)

            #load target
            inputs_tg, labels_tg, name_tg = data_tgt['image'], data_tgt['mask'], data_tgt['name']

            inputs_tg = inputs_tg.type(torch.FloatTensor)
            labels_tg = labels_tg.type(torch.FloatTensor)

            # try:
            #     batch = next(dataset_target_dataloader_iter)
            # except:
            #     dataset_target_dataloader_iter = iter(dataset_target_dataloader)
            #     batch = next(dataset_target_dataloader_iter)
            # targets = batch
            # inputs_tg, labels_tg = targets['image'], targets['mask']
            # inputs_tg = inputs_tg.type(torch.FloatTensor)
            # labels_tg = labels_tg.type(torch.FloatTensor)


            # wrap them in Variable
            if torch.cuda.is_available():
                inputs_v, labels_v = Variable(inputs.cuda(), requires_grad=False), Variable(labels.cuda(), requires_grad=False)
                targets_v, labels_v_tg= Variable(inputs_tg.cuda(), requires_grad=False), Variable(labels_tg.cuda(), requires_grad=False)
            else:
                inputs_v, labels_v = Variable(inputs, requires_grad=False), Variable(labels, requires_grad=False)

            d0, d1, d2, d3, d4, d5,d6,d7,d8,d9 = net(inputs_v)
            t0, t1, t2, t3, t4, t5,t6,t7,t8,t9 = net(targets_v)

            labels_v = t_resize(labels_v)
            labels_v_tg = t_resize(labels_v_tg)

            loss2, loss = muti_loss_fusion(d0, d1, d2, d3, d4, d5, labels_v)


            # if withlabel = 1:
            for m in range(batch_size_train):
                label = False
                if label:
                # if "labeled" in data_tgt['name'][m]:
                    print(data_tgt['name'][m])
                    loss2gt, lossgt = muti_loss_fusion(t0, t1, t2, t3, t4, t5, labels_v_tg)
                    lossgt.backward(retain_graph=True)

            # optimizer_D1.zero_grad()
            adjust_learning_rate_D(optimizer_D1, epoch)
            # adjust_learning_rate_D(optimizer_D01, epoch)
            # adjust_learning_rate_D(optimizer_D02, epoch)
            # adjust_learning_rate_D(optimizer_D11, epoch)
            # adjust_learning_rate_D(optimizer_D12, epoch)
            adjust_learning_rate_D(optimizer_D21, epoch)
            adjust_learning_rate_D(optimizer_D22, epoch)
            adjust_learning_rate_D(optimizer_D31, epoch)
            adjust_learning_rate_D(optimizer_D32, epoch)

            for param in model_D1.parameters():
                param.requires_grad = False
            # for param in model_D01.parameters():
            #     param.requires_grad = False
            # for param in model_D02.parameters():
            #     param.requires_grad = False
            # for param in model_D11.parameters():
            #     param.requires_grad = False
            # for param in model_D12.parameters():
            #     param.requires_grad = False
            for param in model_D21.parameters():
                param.requires_grad = False
            for param in model_D22.parameters():
                param.requires_grad = False
            for param in model_D31.parameters():
                param.requires_grad = False
            for param in model_D32.parameters():
                param.requires_grad = False
            # print(d0.shape,d6.shape)

            # s0 = torch.chunk(torch.mul(d0, d6), 2, dim=1)
            # s01 = s0[0]
            # s02 = s0[1]
            #
            # s01_out_y, s01_out_y_pred = model_D01(s01.detach())  # 10,1 / 10,64,1,1
            # s02_out_y, s02_out_y_pred = model_D02(s02.detach()) #gaile
            #
            # g0 = torch.chunk(torch.mul(t0, t6), 2, dim=1)
            # g01 = g0[0]
            # g02 = g0[0]
            #
            # g01_out_y, g01_out_y_pred = model_D01(g01)  # 10,1 / 10,64,1,1
            # g02_out_y, g02_out_y_pred = model_D02(g02)
            #
            # s1 = torch.chunk(torch.mul(d0, d7), 2, dim=1)
            # s11 = s1[0]
            # s12 = s1[1]
            #
            # s11_out_y, s11_out_y_pred = model_D11(s11.detach())  # 10,1 / 10,64,1,1
            # s12_out_y, s12_out_y_pred = model_D12(s12.detach())  # gaile
            #
            # g1 = torch.chunk(torch.mul(t0, t7), 2, dim=1)
            # g11 = g1[0]
            # g12 = g1[0]
            #
            # g11_out_y, g11_out_y_pred = model_D11(g11)  # 10,1 / 10,64,1,1
            # g12_out_y, g12_out_y_pred = model_D12(g12)

            s2 = torch.chunk(torch.mul(d0, d8), 2, dim=1)
            s21 = s2[0]
            s22 = s2[1]

            s21_out_y, s21_out_y_pred = model_D21(s21.detach())  # 10,1 / 10,64,1,1
            s22_out_y, s22_out_y_pred = model_D22(s22.detach())  # gaile

            g2 = torch.chunk(torch.mul(t0, t8), 2, dim=1)
            g21 = g2[0]
            g22 = g2[0]

            g21_out_y, g21_out_y_pred = model_D21(g21)  # 10,1 / 10,64,1,1
            g22_out_y, g22_out_y_pred = model_D22(g22)

            s3 = torch.chunk(torch.mul(d0, d9), 2, dim=1)
            s31 = s3[0]
            s32 = s3[1]

            s31_out_y, s31_out_y_pred = model_D31(s31.detach())  # 10,1 / 10,64,1,1
            s32_out_y, s32_out_y_pred = model_D32(s32.detach()) #gaile

            g3 = torch.chunk(torch.mul(t0, t9), 2, dim=1)
            g31 = g3[0]
            g32 = g3[0]

            g31_out_y, g31_out_y_pred = model_D31(g31)  # 10,1 / 10,64,1,1
            g32_out_y, g32_out_y_pred = model_D32(g32)



            # optimizer.zero_grad()
            # loss_adapt01 = torch.mean(torch.abs(torch.mean(s01_out_y_pred, 0) - torch.mean(g01_out_y_pred, 0)))
            # loss_adapt02 = torch.mean(torch.abs(torch.mean(s02_out_y_pred, 0) - torch.mean(g02_out_y_pred, 0)))
            # loss_adapt11 = torch.mean(torch.abs(torch.mean(s11_out_y_pred, 0) - torch.mean(g11_out_y_pred, 0)))
            # loss_adapt12 = torch.mean(torch.abs(torch.mean(s12_out_y_pred, 0) - torch.mean(g12_out_y_pred, 0)))
            loss_adapt21 = torch.mean(torch.abs(torch.mean(s21_out_y_pred, 0) - torch.mean(g21_out_y_pred, 0)))
            loss_adapt22 = torch.mean(torch.abs(torch.mean(s22_out_y_pred, 0) - torch.mean(g22_out_y_pred, 0)))
            loss_adapt31 = torch.mean(torch.abs(torch.mean(s31_out_y_pred, 0) - torch.mean(g31_out_y_pred, 0)))
            loss_adapt32 = torch.mean(torch.abs(torch.mean(s32_out_y_pred, 0) - torch.mean(g32_out_y_pred, 0)))

            # loss_adapt31.backward(retain_graph=True)
            # loss_adapt32.backward(retain_graph=True)
            # loss_ada = loss_adapt31+loss_adapt32
            # print(loss_ada, loss_adapt31, loss_adapt32)

            # print(d3.shape)

            d10_out_y, d10_out_y_pred = model_D1(d0.detach())
            t10_out_y, t10_out_y_pred = model_D1(t0)

            loss_adapt1 = torch.mean(torch.abs(torch.mean(d10_out_y_pred, 0) - torch.mean(t10_out_y_pred, 0)))

            # loss_adapt1.backward(retain_graph=True)



            true_label_s = labels_v.data.cpu().numpy()
            sourcelabel = true_label_s
            pred_label_s = d0.data.cpu().numpy()

            pred_label_s = pred_label_s.flatten()
            true_label_s = true_label_s.flatten()
            true_label_s = true_label_s.astype("int")
            # print(pred_label, true_label)
            for a in range(len(pred_label_s)):
                if pred_label_s[a]> 0.5:
                    pred_label_s[a]= 1
                else:
                    pred_label_s[a]=0

            sourcepred = pred_label_s.reshape(2, 384, 384)

            pred_label = t0.data.cpu().numpy()

            true_label = labels_v_tg.data.cpu().numpy()
            targetlabel = true_label

            pred_label = pred_label.flatten()
            true_label = true_label.flatten()
            true_label = true_label.astype("int")
            # print(pred_label, true_label)
            for a in range(len(pred_label)):
                if pred_label[a]> 0.5:
                    pred_label[a]= 1
                else:
                    pred_label[a]=0

            targetpred = pred_label.reshape(2, 384, 384)
            # print(pred_label, true_label)
            # precision_score = precision_score(pred_label, pred_label, average='macro')
            # pred_label = np.reshape(pred_label, [-1])
            # true_label = np.reshape(true_label, [-1])

            # tn= metrics.confusion_matrix(true_label, pred_label).ravel()  # 混淆矩阵各值 fp, fn, tp
            # #tn = metrics.confusion_matrix(true_label_s, pred_label_s).ravel()  # 混淆矩阵各值
            # print(len(tn))
            # exit()
            recall_score = metrics.recall_score(true_label, pred_label, average='macro')  # 召回率
            pre_score = metrics.precision_score(true_label, pred_label, average='macro')  # 准确率
            # recall_score = tp/(tp+fn)
            # pre_score = tp/(tp+fp)
            # acc_hand = (tp+tn)/(tn+fp+fn+tp)

            ACC_T = metrics.accuracy_score(true_label, pred_label)
            ACC_S = metrics.accuracy_score(true_label_s, pred_label_s)# 准确度ACC
            # print("召回率：",recall_score)
            # print("准确率：", pre_score)
            # print("ACC", ACC)
            # print("hand", acc_hand)
            # print(tn, fp, fn, tp)

            # train generator

            feature_img_t10 = t0  # 更新梯度
            D1_out_t10_g, _ = model_D1(feature_img_t10)
            t10_fake_g = Variable(torch.zeros(D1_out_t10_g.size(0), 1).cuda())
            loss_D1_g = criterion(D1_out_t10_g, t10_fake_g)

            feature_img1_g = g31  # 更新梯度
            D31_out_z3_g, _ = model_D31(feature_img1_g)
            y3_fake1_g = Variable(torch.zeros(D31_out_z3_g.size(0), 1).cuda())
            loss_D31_g = criterion(D31_out_z3_g, y3_fake1_g)

            feature_img2_g = g32  # 更新梯度
            D32_out_z3_g, _ = model_D32(feature_img2_g)
            y3_fake2_g = Variable(torch.zeros(D32_out_z3_g.size(0), 1).cuda())
            loss_D32_g = criterion(D31_out_z3_g, y3_fake2_g)

            optimizer.zero_grad()
            # loss_G = loss_D31_g + loss_D32_g + loss_D1_g + loss_adapt1 +loss_adapt01 + loss_adapt02 + loss_adapt11 + loss_adapt12 +loss_adapt21 + loss_adapt22 +loss_adapt31 + loss_adapt32
            loss_G = loss_D31_g + loss_D32_g + loss_D1_g + loss_adapt1 + loss_adapt21 + loss_adapt22 + loss_adapt31 + loss_adapt32
            loss.backward()
            loss_G.backward()

            optimizer.step()



        #train

            for param in model_D1.parameters():
                param.requires_grad = True

            # train with source
            feature_remain_d10 = d0.detach()  # detach does not allow the graddients to back propagate.

            D1_out_d10_remain, _ = model_D1(feature_remain_d10)
            # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            y3_fake_d10 = Variable(torch.zeros(D1_out_d10_remain.size(0), 1).cuda()) #1
            loss_D1_fake = criterion(D1_out_d10_remain, y3_fake_d10)

            # train with gt
            feature_d10 = t0.detach()
            D1_out_t10, _ = model_D1(feature_d10)
            # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            y3_real_t10 = Variable(torch.ones(D1_out_t10.size(0), 1).cuda()) #0
            loss_D1_real = criterion(D1_out_t10, y3_real_t10)

            loss_D1 = (loss_D1_fake + loss_D1_real) / 2.0
            optimizer_D1.zero_grad()
            loss_D1.backward()
            optimizer_D1.step()

            # for param in model_D01.parameters():
            #     param.requires_grad = True
            #
            # # train with pred（跟刚刚那个一样的source，0，相当于把源域当成假）
            # feature_remain_img = s01.detach()  # detach does not allow the graddients to back propagate.
            #
            # D01_out_z3_remain, _ = model_D01(feature_remain_img)
            # # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            # y0_fake_ = Variable(torch.zeros(D01_out_z3_remain.size(0), 1).cuda())
            # loss_D01_fake = criterion(D01_out_z3_remain, y0_fake_)
            #
            # # train with gt（target，1；目标域为真）
            # feature_img = g01.detach()  # 不更新梯度
            # D01_out_z3, _ = model_D01(feature_img)
            # # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            # y0_real_ = Variable(torch.ones(D01_out_z3.size(0), 1).cuda())  # 0
            # loss_D01_real = criterion(D01_out_z3, y0_real_)
            #
            # loss_D01 = (loss_D01_fake + loss_D01_real) / 2.0
            # optimizer_D01.zero_grad()
            # loss_D01.backward()
            # optimizer_D01.step()
            #
            # for param in model_D02.parameters():
            #     param.requires_grad = True
            #
            # # train with pred（跟刚刚那个一样的source，0，相当于把源域当成假）
            # feature_remain_img = s02.detach()  # detach does not allow the graddients to back propagate.
            #
            # D02_out_z3_remain, _ = model_D02(feature_remain_img)
            # # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            # y0_fake_ = Variable(torch.zeros(D02_out_z3_remain.size(0), 1).cuda())
            # loss_D02_fake = criterion(D02_out_z3_remain, y0_fake_)
            #
            # # train with gt（target，1；目标域为真）
            # feature_img = g02.detach()  # 不更新梯度
            # D02_out_z3, _ = model_D02(feature_img)
            # # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            # y0_real_ = Variable(torch.ones(D02_out_z3.size(0), 1).cuda())  # 0
            # loss_D02_real = criterion(D02_out_z3, y0_real_)
            #
            # loss_D02 = (loss_D02_fake + loss_D02_real) / 2.0
            # optimizer_D02.zero_grad()
            # loss_D02.backward()
            # optimizer_D02.step()
            #
            # for param in model_D11.parameters():
            #     param.requires_grad = True
            #
            # # train with pred（跟刚刚那个一样的source，0，相当于把源域当成假）
            # feature_remain_img = s11.detach()  # detach does not allow the graddients to back propagate.
            #
            # D11_out_z3_remain, _ = model_D11(feature_remain_img)
            # # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            # y1_fake_ = Variable(torch.zeros(D11_out_z3_remain.size(0), 1).cuda())
            # loss_D11_fake = criterion(D11_out_z3_remain, y1_fake_)
            #
            # # train with gt（target，1；目标域为真）
            # feature_img = g11.detach()  # 不更新梯度
            # D11_out_z3, _ = model_D11(feature_img)
            # # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            # y1_real_ = Variable(torch.ones(D11_out_z3.size(0), 1).cuda())  # 0
            # loss_D11_real = criterion(D11_out_z3, y1_real_)
            #
            # loss_D11 = (loss_D11_fake + loss_D11_real) / 2.0
            # optimizer_D11.zero_grad()
            # loss_D11.backward()
            # optimizer_D11.step()
            #
            # for param in model_D12.parameters():
            #     param.requires_grad = True
            #
            # # train with pred（跟刚刚那个一样的source，0，相当于把源域当成假）
            # feature_remain_img = s12.detach()  # detach does not allow the graddients to back propagate.
            #
            # D12_out_z3_remain, _ = model_D12(feature_remain_img)
            # # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            # y1_fake_ = Variable(torch.zeros(D12_out_z3_remain.size(0), 1).cuda())
            # loss_D12_fake = criterion(D12_out_z3_remain, y1_fake_)
            #
            # # train with gt（target，1；目标域为真）
            # feature_img = g12.detach()  # 不更新梯度
            # D12_out_z3, _ = model_D12(feature_img)
            # # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            # y1_real_ = Variable(torch.ones(D12_out_z3.size(0), 1).cuda())  # 0
            # loss_D12_real = criterion(D12_out_z3, y1_real_)
            #
            # loss_D12 = (loss_D12_fake + loss_D12_real) / 2.0
            # optimizer_D12.zero_grad()
            # loss_D12.backward()
            # optimizer_D12.step()

            for param in model_D21.parameters():
                param.requires_grad = True

            # train with pred（跟刚刚那个一样的source，0，相当于把源域当成假）
            feature_remain_img = s21.detach()  # detach does not allow the graddients to back propagate.

            D21_out_z3_remain, _ = model_D21(feature_remain_img)
            # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            y2_fake_ = Variable(torch.zeros(D21_out_z3_remain.size(0), 1).cuda())
            loss_D21_fake = criterion(D21_out_z3_remain, y2_fake_)

            # train with gt（target，1；目标域为真）
            feature_img = g21.detach()  # 不更新梯度
            D21_out_z3, _ = model_D21(feature_img)
            # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            y2_real_ = Variable(torch.ones(D21_out_z3.size(0), 1).cuda())  # 0
            loss_D21_real = criterion(D21_out_z3, y2_real_)

            loss_D21 = (loss_D21_fake + loss_D21_real) / 2.0
            optimizer_D21.zero_grad()
            loss_D21.backward()
            optimizer_D21.step()

            for param in model_D22.parameters():
                param.requires_grad = True

            # train with pred（跟刚刚那个一样的source，0，相当于把源域当成假）
            feature_remain_img = s22.detach()  # detach does not allow the graddients to back propagate.

            D22_out_z3_remain, _ = model_D22(feature_remain_img)
            # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            y2_fake_ = Variable(torch.zeros(D22_out_z3_remain.size(0), 1).cuda())
            loss_D22_fake = criterion(D22_out_z3_remain, y2_fake_)

            # train with gt（target，1；目标域为真）
            feature_img = g22.detach()  # 不更新梯度
            D22_out_z3, _ = model_D22(feature_img)
            # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            y2_real_ = Variable(torch.ones(D22_out_z3.size(0), 1).cuda())  # 0
            loss_D22_real = criterion(D22_out_z3, y2_real_)

            loss_D22 = (loss_D22_fake + loss_D22_real) / 2.0
            optimizer_D22.zero_grad()
            loss_D22.backward()
            optimizer_D22.step()


            for param in model_D31.parameters():
                param.requires_grad = True

            # train with pred（跟刚刚那个一样的source，0，相当于把源域当成假）
            feature_remain_img = s31.detach()  # detach does not allow the graddients to back propagate.

            D31_out_z3_remain, _ = model_D31(feature_remain_img)
            # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            y3_fake_ = Variable(torch.zeros(D31_out_z3_remain.size(0), 1).cuda())
            loss_D31_fake = criterion(D31_out_z3_remain, y3_fake_)

            # train with gt（target，1；目标域为真）
            feature_img = g31.detach() #不更新梯度
            D31_out_z3, _ = model_D31(feature_img)
            # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            y3_real_ = Variable(torch.ones(D31_out_z3.size(0), 1).cuda()) #0
            loss_D31_real = criterion(D31_out_z3, y3_real_)

            loss_D31 = (loss_D31_fake + loss_D31_real) / 2.0
            optimizer_D31.zero_grad()
            loss_D31.backward()
            optimizer_D31.step()

            for param in model_D32.parameters():
                param.requires_grad = True

            # train with source
            feature_remain_img = s32.detach()  # detach does not allow the graddients to back propagate.

            D32_out_z3_remain, _ = model_D32(feature_remain_img)
            # y3_fake_ = Variable(torch.zeros(D_out_z3.size(0), 1).cuda(args.gpu))
            y3_fake_ = Variable(torch.zeros(D32_out_z3_remain.size(0), 1).cuda())
            loss_D32_fake = criterion(D32_out_z3_remain, y3_fake_)

            # train with gt
            feature_img = g32.detach()
            D32_out_z3, _ = model_D32(feature_img)
            # y3_real_ = Variable(torch.ones(D_out_z3_gt.size(0), 1).cuda(args.gpu))
            y3_real_ = Variable(torch.ones(D32_out_z3.size(0), 1).cuda()) #0
            loss_D32_real = criterion(D32_out_z3, y3_real_)

            loss_D32 = (loss_D32_fake + loss_D32_real) / 2.0

            optimizer_D32.zero_grad()
            loss_D32.backward()
            optimizer_D32.step()

            # loss_D = loss_D1 + loss_D01 + loss_D02 + loss_D11 + loss_D12 + loss_D21 + loss_D22 + loss_D31 + loss_D32
            loss_D = loss_D1 + loss_D21 + loss_D22 + loss_D31 + loss_D32


            # # print statistics
            running_loss += loss.data.item()
            for m in range(batch_size_train):
                label = False
                if label:
               # if "labeled" in data_tgt['name'][m]:
                   running_gt_loss += lossgt.data.item()

            print("[epoch: %3d/%3d, batch: %5d/%5d, ite: %d] lossG : %3f lossScr: %3f lossD: %3f  " % (
                epoch + 1, epoch_num, (i + 1) * batch_size_train, train_num, ite_num, loss_G.item(), loss.item(),loss_D.item()))
            for m in range(batch_size_train):
                label = False
                if label:
               # if "labeled" in data_tgt['name'][m]:
                   print("lossTGT:", lossgt.item())
            # print('acc={0:.3f},acc_hand={0:.3f}, pre_score={0:.3f}, recall={0:.3f},'.format(ACC, acc_hand, pre_score, recall_score))
            print("召回率：", recall_score)
            print("准确率：", pre_score)
            print("ACC_tgt:", ACC_T)
            print("ACC_scr:", ACC_S)
            # print("hand", acc_hand)

            for j in range(batch_size_train):
                out_dir = os.path.join(r'E:/code/boundarynet/outpred_NEW4UDA/' + f'{(epoch + 1):04d}') #('/media/xk/新加卷/code/boundarynet/outpred_NEW8UDA/' + f'{(epoch + 1):04d}')
                os.makedirs(out_dir, exist_ok=True)
                image_s = Image.open(r'D:/wwxdata/' + data_scr['name'][j])

                # print(j,data_scr['name'][j],data_tgt['name'][j])
                image_t = Image.open(r'D:/wwxdata/' + data_tgt['name'][j])#('/media/xk/新加卷/code/DAFormer-master/data/' + data_tgt['name'][j])
                image_tori = Image.open(r'D:/wwxdata/' + data_tgt['name'][j])
                imagename = data_tgt['name'][j]
                # print(os.path.join(out_dir, imagename))
                rows, cols = 2, 4
                fig, axs = plt.subplots(
                    rows,
                    cols,
                    figsize=(4 * cols, 4 * rows),
                )
                subplotimg(axs[0][0], np.asarray(image_s), 'Source Image')
                subplotimg(axs[0][1], np.asarray(image_s), 'Source Image')
                subplotimg(axs[0][2],
                           sourcelabel[j],  # gt_semantic_seg[j],
                           'Source label',
                           cmap='cityscapes')
                subplotimg(axs[0][3],
                           sourcepred[j],  # gt_semantic_seg[j],
                           'Source Pred',
                           cmap='cityscapes')

                subplotimg(axs[1][0], np.asarray(image_tori), 'target Image')
                subplotimg(axs[1][1], np.asarray(image_t), 'Style target Image')
                subplotimg(axs[1][2],
                    targetlabel[j],  # gt_semantic_seg[j],
                    'target label',
                    cmap='cityscapes')
                subplotimg(axs[1][3],
                    targetpred[j],  # gt_semantic_seg[j],
                    'target Pred',
                    cmap='cityscapes')

                for ax in axs.flat:
                    ax.axis('off')
                plt.savefig(out_dir+'/' + imagename[17:])
                plt.close()
                # inputtarget = inputs_tg[j].data.cpu().numpy()
                # Writer.add_image('img_tg', inputtarget.squeeze().transpose((1,2,0)), 1, dataformats='HWC')
                # Writer.add_image('label_tg', targetlabel[j].transpose((1,2,0)), 1, dataformats='HWC')
                # Writer.add_image('pred_tg', targetpred[j].reshape(1,384,384).transpose((1,2,0)), 1, dataformats='HWC')
            # Writer.add_scalar("lossAda", loss_adapt31+loss_adapt32+loss_adapt1, ite_num)
            Writer.add_scalar("loss_G", loss_G, ite_num)
            Writer.add_scalar("lossScr", loss.item(), ite_num)
            Writer.add_scalar("loss_D", loss_D.item(), ite_num)
            for m in range(batch_size_train):
                label = False
                if label:
                # if "labeled" in data_tgt['name'][m]:
                  Writer.add_scalar("lossTGT", lossgt.item(), ite_num)
                  Writer.add_scalar("losstgt", loss2gt.item(), ite_num)
            # Writer.add_scalar("train loss", running_loss / ite_num4val, ite_num)
            # Writer.add_scalar("train", loss.data, ite_num)
            # Writer.add_scalar("tar", loss2.data, ite_num)
            Writer.add_scalar("acc_scr", ACC_S, ite_num)
            Writer.add_scalar("acc_tgt", ACC_T, ite_num)
            Writer.add_scalar("pre_score", pre_score, ite_num)
            Writer.add_scalar("recall", recall_score, ite_num)

            del d0, d1, d2, d3, d4, d5, loss2, loss,loss_adapt21, loss_adapt22,loss_adapt31, loss_adapt32, loss_adapt1,loss_D21, loss_D22,loss_D31, loss_D32


        checkpoint_dict = {
            'epoch': epoch,
            'model_state_dict': net.state_dict(),
            'optim_state_dict': optimizer.state_dict()
        }

        if (epoch+1) % save_interval_epoch == 0:
            torch.save(checkpoint_dict, model_dir + "epoch%d_boundarynets_bsi_itr_%lossScr%3f_lossTGT_%3f.pth" % (
                epoch+1, ite_num, running_loss / ite_num4val, running_gt_loss /ite_num4val))



        running_loss = 0.0
        running_gt_loss = 0.0
        valid_loss = 0.0
        valid_target_loss = 0.0
        ite_num4val = 0
        end_time = time.time()
        time_for_each_epoch.append(end_time - start_time)
        print('time:', end_time - start_time)


    # Writer.close()
    print('-------------Congratulations! Training Done!!!-------------')
    print('-'*20, "Now save the log file of the train processing...", '-'*20)

    with open("time_recoder.txt", "w+") as f:
        f.writelines(time_for_each_epoch)
    print('-'*20, "Done!", '-'*20)
    print("End time:" + str(datetime.datetime.now().strftime('%y-%m-%d %H:%M:%S')))


