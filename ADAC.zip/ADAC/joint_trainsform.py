#encoding = utf-8
import random

import numpy as np
import torch
from PIL import Image, ImageFilter
from torchvision.transforms import transforms


class Compose(object):
    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, img, mask):
        assert img.size == mask.size
        for t in self.transforms:
            img, mask = t(img, mask)
        return img, mask


class RandomHorizontallyFlip(object):
    def __call__(self, sample):
        img,mask = sample['image'],sample['mask']
        if random.random() < 0.5:
            return {'image':torch.flip(img,[1,2]), 'mask':torch.flip(mask,[1,2])}
        return {'image': img,
                'mask': mask}


class JointResize(object):
    def __init__(self, size):
        if isinstance(size, int):
            self.size = (size, size)
        elif isinstance(size, tuple):
            self.size = size
        else:
            raise RuntimeError("size shoud set int or tuple")

    def __call__(self, img, mask):
        img = img.resize(self.size, resample=Image.BILINEAR)
        mask = mask.resize(self.size, resample=Image.NEAREST)
        return img, mask


class RandomRotate(object):
    def __init__(self, degree):
        self.degree = degree

    def __call__(self, sample):
        img, mask = sample['image'], sample['mask']
        rotate_degree = int(random.random() * 2* self.degree - self.degree)
        if rotate_degree<0:
            rotate_degree = rotate_degree+360
        #print(rotate_degree)
        return {'image':transforms.RandomRotation(rotate_degree)(img),'mask':transforms.RandomRotation(rotate_degree)(mask)}


class RandomScaleCrop(object):
    def __init__(self, input_size, scale_factor):
        """
        zoom in and cut
        """
        self.input_size = input_size
        self.scale_factor = scale_factor

    def __call__(self, img, mask):
        # random scale (short edge)
        assert img.size[0] == self.input_size

        o_size = random.randint(int(self.input_size * 1), int(self.input_size * self.scale_factor))
        img = img.resize((o_size, o_size), resample=Image.BILINEAR)
        mask = mask.resize((o_size, o_size), resample=Image.NEAREST)  

        # random crop input_size
        x1 = random.randint(0, o_size - self.input_size)
        y1 = random.randint(0, o_size - self.input_size)
        img = img.crop((x1, y1, x1 + self.input_size, y1 + self.input_size))
        mask = mask.crop((x1, y1, x1 + self.input_size, y1 + self.input_size))

        return img, mask


class ScaleCenterCrop(object):
    def __init__(self, input_size):
        self.input_size = input_size

    def __call__(self, img, mask):
        w, h = img.size
        
        if w > h:
            oh = self.input_size
            ow = int(1.0 * w * oh / h)
        else:
            ow = self.input_size
            oh = int(1.0 * h * ow / w)
        img = img.resize((ow, oh), resample=Image.BILINEAR)
        mask = mask.resize((ow, oh), resample=Image.NEAREST)

        
        w, h = img.size
        x1 = int(round((w - self.input_size) / 2.0))
        y1 = int(round((h - self.input_size) / 2.0))
        img = img.crop((x1, y1, x1 + self.input_size, y1 + self.input_size))
        mask = mask.crop((x1, y1, x1 + self.input_size, y1 + self.input_size))

        return img, mask


class RandomGaussianBlur(object):
    def __call__(self, img, mask):
        if random.random() < 0.5:
            img = img.filter(ImageFilter.GaussianBlur(radius=random.random()))

        return img, mask


if __name__ == "__main__":
    a = torch.randn((3, 320, 320))
    b = torch.randn((1, 320, 320))
    to_pil = transforms.ToPILImage()

    a = to_pil(a)
    b = to_pil(b)
    lu_x, lu_y, rb_x, rb_y = (320, 320, 544, 544)
    b.crop((lu_x, lu_y, rb_x, rb_y))
    print(np.asarray(b.crop((lu_x, lu_y, rb_x, rb_y))))
