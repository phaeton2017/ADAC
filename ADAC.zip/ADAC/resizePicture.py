import os
from PIL import Image
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import io,data

folderPath = 'label'

def save_resize_img(img_path, img_path_train, width, height):
    for i in os.listdir(img_path):
        image = os.path.join(img_path, i)
        img = Image.open(image)
        img = img.resize((width, height), Image.ANTIALIAS)
        img.save(img_path_train + i)

def to255():
    for img in os.listdir(floderPath):
        image_path = os.path.join(floderPath, img)
        print(image_path)
        if 'png' in image_path:
            print(image_path)
            image = cv2.imread(image_path)
            image = (np.maximum(image, 0) / 255) #* 255.0
            image = np.uint8(image)
            cv2.imwrite(f'/media/xk/home/zfxDatasetAll/dataset5/target/Label_01/{img}', image)  #save_path为保存路径
if __name__=="__main__":
    # save_resize_img(r"/media/xk/新加卷/数据集/feixiang/WHU_Building_dataset1/train_before/images_styled/",
    #                 r"/media/xk/新加卷/数据集/feixiang/WHU_Building_dataset1/train_before/images_styled_512/", 512, 512)
    floderPath = r'/media/xk/home/zfxDatasetAll/dataset5/target/Label'
    to255()