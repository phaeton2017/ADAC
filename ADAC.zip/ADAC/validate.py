import os
import random
from functools import partial
# from skimage import io, transform
import torch
import torchvision
from sklearn import metrics
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

import numpy as np
from PIL import Image

from torchvision import transforms, utils
from torchvision.transforms import Resize
from data_loader_SPARCS import ToTensorNorm, CloudDataset

from model import BoundaryNets
# np.set_printoptions(threshold=np.inf)
import pandas as pd

# use cudnn
# torch.backends.cudnn.benchmark = True
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

t_resize = Resize([320, 320])
low_thre = 90
high_thre =249
epoch = 0

def ensure_dir(dir_path):
    if not os.path.isdir(dir_path):
        os.makedirs(dir_path)


def normPRED(d):
    ma = torch.max(d)
    mi = torch.min(d)

    dn = (d - mi) / (ma - mi)

    return dn


# define the global seed
# def set_seed(seed = 1234):
#     random.seed(seed)
#     np.random.seed(seed)
#     os.environ['PYTHONHASHSEED'] = str(seed)
#     torch.manual_seed(seed)

colormap = []
pd_label_color = pd.read_csv(r'/home/xk/PycharmProjects/boundary-nets-master_new/class_dict_path.csv', sep=',')


# for i in range(2):
#    tmp = pd_label_color.iloc[i]
#    color = [tmp['r'], tmp['g'], tmp['b']]
#    colormap.append(color)

# cm = np.array(colormap).astype('uint8')
def save_output(image_name, pred, d_dir):
    predict = pred
    predict = predict.squeeze()
    predict_np = (predict * 255).astype(np.uint8)
    # print("SAVE", predict_np)
    # print(predict_np.shape)
    # color_file = Image.fromarray(colorize(predict_np).transpose(1, 2, 0), 'RGB')
    im = Image.fromarray(predict_np).convert('RGB')
    # im.show()
    # img = Image.fromarray(colorize(color_file).transpose(1, 2, 0), 'RGB')
    im.save(d_dir + image_name + '.png')


# --------- 1. get image path and name ---------
test_list_txt = "/home/xk/data/LANDSAT/land/test.txt"
prediction_dir = "/home/xk/PycharmProjects/boundary-nets-master_new/result78/"
model_dir = "/home/xk/PycharmProjects/boundary-nets-master_new/saved_models_per/epoch78_boundarynets_bsi_itr_9937_train_3.243032_tar_0.265713.pth"
model_acc_dir = '/home/xk/PycharmProjects/boundary-nets-master_new/modelacc_dir/'
# ensure_dir(model_dir)
# model.eval()
ensure_dir(prediction_dir)

is_resume_loadmodel_accbest = False
model_accbest_dir = '/home/xk/PycharmProjects/boundary-nets-master_new/modelacc_dir/'
ensure_dir(model_accbest_dir)

if is_resume_loadmodel_accbest:
    checkpoint = torch.load('/home/xk/PycharmProjects/boundary-nets-master_new/saved_models_per/epoch60_boundarynets_bsi_itr_3138_train_3.402684_tar_0.290037.pth')
    low_thre.load_state_dict(checkpoint['下界值'])
    high_thre.load_state_dict(checkpoint['上界值'])



with open(test_list_txt, 'r', encoding='utf-8') as f:
    test_list = f.readlines()
test_list = [val.replace("\n", "") for val in test_list]
# set_seed(20211130)


# --------- 2. dataloader ---------
# test_salobj_dataset = CloudDataset(file_name_list=test_list,
#                                     transform=transforms.Compose([ToTensorNorm()]),
#                                     test_mode=1)
test_salobj_dataset = CloudDataset(file_name_list=test_list,
                                   transform=transforms.Compose([ToTensorNorm()]),
                                   test_mode=1)
test_salobj_dataloader = DataLoader(test_salobj_dataset, batch_size=1, shuffle=False, num_workers=1)

# --------- 3. model define ---------
print("...load BoundaryNets...")
net = BoundaryNets(3, 1)

if torch.cuda.is_available():
    if len(os.environ["CUDA_VISIBLE_DEVICES"].split(",")) > 1:
        net = nn.DataParallel(net)
    net = net.cuda()
net.load_state_dict(torch.load(model_dir)['model_state_dict'], False)

# model_dict = net.state_dict()
# pretrained_dict = {k: v for k, v in torch.load(model_dir)['model_state_dict'].items() if k in model_dict}
# model_dict.update(pretrained_dict)
# net.load_state_dict(model_dict)


net.eval()
maxval = len(test_salobj_dataloader)
# --------- 4. inference for each image ---------
for low_thre in range(low_thre, 110, 2):

    for high_thre in range(high_thre, 255, 2):

        acc = 0
        epoch = epoch+1

        for i_test, data_test in enumerate(test_salobj_dataloader):
            inputs_test, label_test = data_test['image'], data_test['mask']
            # print(inputs_test)

            if inputs_test[:, 0, :, :].sum() == 0:
                pred = np.zeros((321, 321))
                im = Image.fromarray(np.uint8(pred)).convert('RGB')
                im.save(prediction_dir + test_list[i_test][10:-4] + '.png')
            else:
                inputs_test = inputs_test.type(torch.FloatTensor)
                label_test = label_test.type(torch.FloatTensor)  #

                if torch.cuda.is_available():
                    inputs_test = Variable(inputs_test.cuda())
                    label_test = Variable(label_test.cuda())  #
                else:
                    inputs_test = Variable(inputs_test)
                    label_test = Variable(label_test.cuda())  #

                d1, d2, d3, d4, d5, d6, d7, d8 = net(inputs_test)
                # b1, b2, b3, b4, b5, b6, b7, b8 = net(inputs_test)
                # print(d1, b1)
                # print(d1 == b1)
                # acc
                label_test = t_resize(label_test)
                true_label = label_test.data.cpu().numpy()
                true_label = true_label.flatten()
                true_label = true_label.astype("int")
                # end

                pred = d1[:, 0, :, :]
                # print(pred)

                # pred = F.log_softmax(pred)
                # print(pred)

                pred = normPRED(pred)

                # print(pred)
                # print(pred.shape)
                pred_np = pred.data.cpu().numpy() * 255
                # print(pred_np)
                # pred_np = pred_np.astype(int)
                # print(pred_np.shape, pred_np.dtype)
                pred_np = pred_np.flatten()
                # print(pred_np)
                for a in range(len(pred_np)):
                    if pred_np[a] > low_thre and pred_np[a] < high_thre:
                        pred_np[a] = 1
                    else:
                        pred_np[a] = 0
                # print(pred_np)
                pred_np = pred_np.astype(np.uint8)
                # print(pred_np, pred_np.dtype)
                # 计算acc
                # tn, fp, fn, tp = metrics.confusion_matrix(true_label, pred_np).ravel()  # 混淆矩阵各值
                # # print(tn,fp,fn,tp)
                # # recall_score = metrics.recall_score(true_label, pred_label, average='macro')  # 召回率
                # # pre_score = metrics.precision_score(true_label, pred_label, average='macro')  # 准确率
                # recall_score = tp/(tp+fn)
                # pre_score = tp/(tp+fp)
                # acc_hand = (tp+tn)/(tn+fp+fn+tp)
                ACC = metrics.accuracy_score(true_label, pred_np)
                # acc = acc+ACC
                # print("ACC", ACC)
                acc = acc + ACC
                # end
                # pred_np = torch.tensor(pred_np)
                # print(pred_np)
                pred_np = pred_np.reshape((1, 320, 320))
                # pred_np = cm[pred_np]
                # pred_np =pred_np.squeeze()
                # print(pred_np, pred_np.dtype, pred_np.shape)

                # print(pred_np.shape)

                # pre = Image.fromarray(np.uint8(pred_np))
                # pre.save('/home/xk/PycharmProjects/boundary-nets-master_new/result25/' + test_list[i_test][10:-4] + '.png')

                # print(pred_np)
                # save_output(test_list[i_test][10:-4], pred_np, prediction_dir)
                del d1, d2, d3, d4, d5, d6, d7, d8
            # print("[%d / %d]inferencing %s" % (i_test, maxval, test_list[i_test].split("/")[-1]))
        aveacc = acc / len(test_list)
        print(low_thre, high_thre)
        print('平均acc：', aveacc)

        checkpoint_dict = {
            'acc': aveacc,
            '下界值': low_thre,
            '上界值': high_thre
        }
        if (epoch + 1) % 6 == 0:
            print('....saving checkpoint')
            torch.save(checkpoint_dict, model_acc_dir + "acc_%3f_low_%3f_high_%3f.pth" % (
                aveacc, low_thre, high_thre))
